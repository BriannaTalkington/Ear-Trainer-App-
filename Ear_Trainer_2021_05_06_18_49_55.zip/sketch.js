class PlayBtn {
  constructor(x, y) {
    //triangle 
    this.x = x-30;
    this.y = y-70;
    this.h = 190;
    this.w = 190;
    //outside of triangle 
    this.buffer = 5;
    this.r = 3
  }
  
  show() {
    // Add rect here
    rect(this.x, this.y, this.w, this.h, this.r);
    triangle(this.x + this.buffer, this.y + this.buffer,
            this.x + this.w - this.buffer, this.y + (this.h/2),
            this.x + this.buffer, this.y + this.h - this.buffer)
  }
}
//mouse clicked 
function wasClicked(obj) {
  var test1 = mouseX >= obj.x;
  var test2 = mouseX <= obj.x + obj.w;
  var test3 = mouseY >= obj.y;
  var test4 = mouseY <= obj.y + obj.h;
  //to see if area is touched 
  if (test1 && test2 && test3 && test4) {
    return true
  } else {
    return false
  }
}

var playBtn
var soundTimer = 9000
let monoSynth;
//sound
function setup() {
  createCanvas(600, 400);
  playBtn = new PlayBtn(100, 200);
  monoSynth = new p5.MonoSynth();
}

function draw() {
  background(220);
  //rect(30, 90, 290, 250);
 //text size for words 
let s = 'Click here for sound';
text(s, 35, 40, 290, 200);
  textSize(32)
  // Text wraps within text box
//triangle(100, 280, 300, 200,100,150);
 playBtn.show()
}
//sound of notes 
function playSynth() {
  userStartAudio();

  let note = random(['Fb4', 'G4']);
  // note velocity (volume, from 0 to 1)
  let velocity = random();
  // time from now (in seconds)
  let time = 0;
  // note duration (in seconds)
  let dur = 1/6;

  monoSynth.play(note, velocity, time, dur);
}

// when mouse is clicked do this
function mouseClicked() {
  if (wasClicked(playBtn)) {
    playSynth();
  }
}

                                       