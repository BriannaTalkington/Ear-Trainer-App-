class Button{
  constructor(x,y, t){ 
    this.x = x;
    this.y = y;
    this.h = 40;
    this.w = 70;
    this.tune = t // 0 = flat, 1 = in-tune, 2 = sharp
    this.r = 255
    this.g = 0
    this.b = 0
  }
  
  show() {
    fill(this.r, this.g, this.b)
    rect(this.x, this.y, this.w, this.h)
    fill(0,0,0)
    textSize(22)
    text("flat",270,100)
    text("in-tune",252,200)
    text("sharp",260,300)
  }
  
  
  clicked() {
    if (this.r == 255) {
      this.r = 0
      this.g = 255
    } else{
      this.r = 255
      this.g = 0
    }
  }

}//end of buttons
function selected (obj){
  var test1 = mouseX >= obj.x
  var test2 = mouseX <= obj.x + obj.w
  var test3 = mouseY >= obj.y
  var test4 = mouseY <= obj.y + obj.h
  
  return (test1 && test2 && test3 && test4)
}
var buttons = []

function setup(){
 createCanvas(400,400)
  buttons.push(new Button(250, 70, 0))
  buttons.push(new Button(250, 170, 1))
  buttons.push(new Button(250, 270, 2))
}
function draw(){
  background(220)
   for(var n in buttons){
     buttons[n].show()
   }
  
}

function mouseClicked(){
  //console.log("Brianna broke it.")
  for (var b in buttons) {
    if (selected(buttons[b])) {
      buttons[b].clicked();
    }
  }
}

