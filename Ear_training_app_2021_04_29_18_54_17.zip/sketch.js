function setup(){
 createCanvas(400,400)
}
function draw(){
  background(220)
   sharp = rect(250,70,80,50)
   intune = rect(250,170,80,50)
  flat = rect(250,270,80,50)
}
class buttons{
  constructor(x,y,l,w){ 
    this.x = x;
    this.y = y;
    this.l = l;
    this.w = w;
    this.sharp = true
    
     
  }

}//end of buttons
function mouseClicked(){
 if(sharp == true){
   sharp = fill(50)
  intune = fill(20)
} else{
  sharp = fill(0)
}
}

